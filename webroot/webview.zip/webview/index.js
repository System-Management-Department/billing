import { Webview } from "https://deno.land/x/webview@0.7.6/mod.ts";
const config = await fetch(import.meta.resolve("./config.json")).then(res => res.json());

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const webview = new Webview();
webview.navigate(config.navigate);
webview.bindRaw("corsFetch", (seq, req, arg) => {
	const file = new URL(`cache/${seq}.json`, import.meta.url).pathname.replace(/^\/(.+:)/, "$1");
	Deno.writeFileSync(file, encoder.encode(req));
	const command = new Deno.Command(new URL("cache_cmd", import.meta.url).pathname.replace(/^\/(.+:)/, "$1"), {args: [import.meta.resolve(`./cache/${seq}.json`)]});
	const { stdout } = command.outputSync();
	const resText = decoder.decode(stdout).trim();
	console.log(resText);
	webview.return(seq, 0, JSON.stringify(resText));
});
webview.run();
