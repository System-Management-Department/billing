const config = await fetch(import.meta.resolve("./config.json")).then(res => res.json());
const dataList = await fetch(Deno.args[0]).then(res => res.json());
const encoder = new TextEncoder();
let p = [];
for(let fetchData of dataList){
	let [url, options] = fetchData;
	url = stringRaw(url);
	if("headers" in options){
		const headers = new Headers();
		for(let item of options.headers){
			let [k, v] = item;
			headers.append(stringRaw(k), stringRaw(v));
		}
		options.headers = headers;
	}
	if("body" in options){
		const body = new FormData();
		for(let item of options.body){
			if(item.length == 2){
				const [k, v] = item;
				body.append(stringRaw(k), stringRaw(v));
			}else if(item.length == 3){
				const [k, f, n] = item;
				const blob = await fetch(f).then(res => res.blob());
				body.append(stringRaw(k), blob, stringRaw(n));
			}
		}
		options.body = body;
	}
	p.push(fetch(url, options).then(res => res.text()));
}

const results = await Promise.all(p);
console.log(`[${results.join(",")}]`);
const file = new URL(`cache/log.txt`, import.meta.url).pathname.replace(/^\/(.+:)/, "$1");
Deno.writeFileSync(file, encoder.encode(`[${results.join(",")}]`));

function stringRaw(value){
	if(Array.isArray(value)){
		const args = value.map((e, i) => {
			if(i < 1){
				return e;
			}
			if(e == "config.endpoint"){
				return config.endpoint;
			}else if(e == "config.apiToken"){
				return config.apiToken;
			}
			return null;
		});
		return String.raw(...args);
	}
	return value;
}
