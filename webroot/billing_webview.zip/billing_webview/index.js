import { Webview } from "https://deno.land/x/webview/mod.ts";
const config = await fetch(import.meta.resolve("./config.json")).then(res => res.json());

const decoder = new TextDecoder();
const webview = new Webview();
webview.navigate(config.navigate);
webview.bindRaw("cacheOpen", (seq, req, arg) => {
	const command = new Deno.Command(new URL("cache_cmd", import.meta.url).pathname.replace(/^\/(.+:)/, "$1"), {args: ["open", seq]});
	const { stdout } = command.outputSync();
	webview.return(seq, 0, JSON.stringify(decoder.decode(stdout).trim()));
});
webview.bindRaw("cacheWrite", (seq, req, arg) => {
	const command = new Deno.Command(new URL("cache_cmd", import.meta.url).pathname.replace(/^\/(.+:)/, "$1"), {args: ["write"].concat(JSON.parse(req))});
	const { stdout } = command.outputSync();
	webview.return(seq, 0, JSON.stringify(decoder.decode(stdout).trim()));
});
webview.bindRaw("cacheRun", (seq, req, arg) => {
	const command = new Deno.Command(new URL("cache_cmd", import.meta.url).pathname.replace(/^\/(.+:)/, "$1"), {args: ["run"].concat(JSON.parse(req))});
	const { stdout } = command.outputSync();
	webview.return(seq, 0, JSON.stringify(decoder.decode(stdout).trim()));
});
webview.run();
