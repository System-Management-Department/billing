import { encodeUrl } from "https://deno.land/x/encodeurl@1.0.0/mod.ts";
if(Deno.args[0] == "open"){
	await Deno.writeTextFile(new URL(`cache/${Deno.args[1]}.js`, import.meta.url).pathname.replace(/^\/(.+:)/, "$1"), "");
	console.log(Deno.args[1]);
}else if(Deno.args[0] == "write"){
	await Deno.writeFile(new URL(`cache/${Deno.args[1]}.js`, import.meta.url).pathname.replace(/^\/(.+:)/, "$1"), await fetch(Deno.args[2]).then(res => res.arrayBuffer()), {append: true});
	console.log(Deno.args[1]);
}else if(Deno.args[0] == "run"){
	const config = await fetch(import.meta.resolve("./config.json")).then(res => res.json());
	Promise.all(
		Deno.args.slice(2).concat(import.meta.resolve(`./cache/${Deno.args[1]}.js`))
			.map(url => fetch(url).then(res => res.text()))
	)
		.then(script => import(`data:application/javascript,${encodeUrl(script.join("\n"))}`))
		.then(mod => mod.run(config))
		.then(console.log);
}